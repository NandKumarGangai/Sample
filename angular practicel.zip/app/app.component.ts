import { Component} from 'angular2/core'; //importing Component from the angular2/core
import {ProductlistComponent} from './products/product-list.component';
@Component({
    selector: 'pm-app', //selector creates the html tag which can be embedded in HTML
    template: `<pm-products>Loading....</pm-products>`,
    
    directives: [ProductlistComponent]
    //Here we specifies the template for showing data
})  //In angular metadata is specified by using @Component 

export class AppComponent{
    pageTitle:string = "ACME Product Managament";
    
}