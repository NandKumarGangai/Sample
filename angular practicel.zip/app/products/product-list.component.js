System.register(['angular2/core', './product-list.pipe', '../shared/star.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, product_list_pipe_1, star_component_1;
    var ProductlistComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (product_list_pipe_1_1) {
                product_list_pipe_1 = product_list_pipe_1_1;
            },
            function (star_component_1_1) {
                star_component_1 = star_component_1_1;
            }],
        execute: function() {
            ProductlistComponent = (function () {
                function ProductlistComponent() {
                    this.pageTitle = "Product List";
                    this.products = [
                        {
                            "productId": 2,
                            "productName": "Garden Cart",
                            "productCode": "GDN-0023",
                            "releaseDate": "March 18, 2016",
                            "description": "15 gallon capacity rolling garden cart",
                            "price": 32.99,
                            "starRating": 4.2,
                            "imageUrl": "https://www.gstatic.com/webp/gallery3/1.png"
                        },
                        {
                            "productId": 5,
                            "productName": "Hammer",
                            "productCode": "TBX-0048",
                            "releaseDate": "May 21, 2016",
                            "description": "Curved claw steel hammer",
                            "price": 8.9,
                            "starRating": 4.8,
                            "imageUrl": "https://www.gstatic.com/webp/gallery3/2.png"
                        }
                    ];
                    this.imgWidth = 30;
                    this.imgMargin = 10;
                    this.showImage = false;
                    this.listFilter = '';
                }
                ProductlistComponent.prototype.toggleImage = function () { this.showImage = !this.showImage; };
                ProductlistComponent.prototype.ngOnInit = function () {
                    console.log("on Init Fired...");
                    $.get('app/products/product-data.json', function (data, status) {
                        console.log(status);
                        console.log(data);
                    });
                };
                ProductlistComponent.prototype.onRatingClicked = function (message) {
                    this.pageTitle = ' Product List ' + message;
                };
                ProductlistComponent = __decorate([
                    core_1.Component({
                        selector: 'pm-products',
                        /*template: `<h1>PRODUCT LIST COMPONENT</h1>`*/
                        templateUrl: 'app/products/product-list.component.html',
                        styleUrls: ['app/products/product-list.component.css'],
                        pipes: [product_list_pipe_1.productFilterPipe],
                        directives: [star_component_1.StarComponent]
                    }), 
                    __metadata('design:paramtypes', [])
                ], ProductlistComponent);
                return ProductlistComponent;
            }());
            exports_1("ProductlistComponent", ProductlistComponent);
        }
    }
});
//# sourceMappingURL=product-list.component.js.map