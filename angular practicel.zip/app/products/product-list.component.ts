import {Component, OnInit} from 'angular2/core';
import {IProduct} from './product';
import {productFilterPipe} from './product-list.pipe';
import {StarComponent} from '../shared/star.component';
@Component({
    selector: 'pm-products',
    /*template: `<h1>PRODUCT LIST COMPONENT</h1>`*/
    templateUrl: 'app/products/product-list.component.html',
    styleUrls: ['app/products/product-list.component.css'],
    pipes: [productFilterPipe],
    directives: [StarComponent]
})

export class ProductlistComponent implements OnInit{
    pageTitle:string = "Product List";
    products:IProduct[]=[
        {
            "productId": 2,
            "productName": "Garden Cart",
            "productCode": "GDN-0023",
            "releaseDate": "March 18, 2016",
            "description": "15 gallon capacity rolling garden cart",
            "price": 32.99,
            "starRating": 4.2,
            "imageUrl": "https://www.gstatic.com/webp/gallery3/1.png"
        },
        {
            "productId": 5,
            "productName": "Hammer",
            "productCode": "TBX-0048",
            "releaseDate": "May 21, 2016",
            "description": "Curved claw steel hammer",
            "price": 8.9,
            "starRating": 4.8,
            "imageUrl": "https://www.gstatic.com/webp/gallery3/2.png"
        }
    ];
    imgWidth:number = 30;
    imgMargin:number = 10;
    showImage:boolean = false;
    toggleImage():void{ this.showImage=!this.showImage;}
    listFilter:string = '';

    ngOnInit():void{
        console.log("on Init Fired...");
        $.get('app/products/product-data.json', function(data, status){
            console.log(status);
            console.log(data);            
        });
    }

    onRatingClicked(message: string):void{
        this.pageTitle = ' Product List '+message;
    }
}