var App={ questions:""};
App.setQuestion = function(questions){ this.questions = questions;}
App.getQuestion = function(questions){ return this.questions;}

$(document).ready(function(){
	//$("#quizzSection").hide();
	$("#rulesSection").hide();
});


App.checkCredentials = function (){
	
	var uname = document.getElementById("txtUserName").value;
	var pass = document.getElementById("txtPassword").value;
	
	//$.get("authentication.json", function(data, status){
	$.get("authentication.txt", function(data, status){
		var users = JSON.parse(data);
		console.log(users);
		let flag = false;
		for(user of users){
			
			if(user.username == uname && user.password==pass){
				
				$("#rulesSection").show();
				$("#loginSection").hide();
				$("#rulesSection").load("rules.html");
				flag = true;
				break;
			}
		}
		if(flag == false){
			
			console.log("Invalid");
			document.getElementById("errLogin").innerHTML = "Invalid login credentials...";
		}
		
	});
	return false;
}


App.startQuizz = function (){

	//$.get("questions.json", function(data, status){
	$.get("questions.txt", function(data, status){
	
		App.setQuestion(JSON.parse(data));
		//$("#examSection").load("exam.html");
		let queSet = App.getQuestion();

		for(que of queSet){
			var para = document.createElement("p");
			para.innerHTML = que.que;
			$("#examSection").append(para);
			var $ctrl1 = $('<input/>').attr({ type: 'radio', id:'ans1'});
			var $s1 = $('<span>'+que.A +'</span>');
			$("#examSection").append($ctrl1);
			$("#examsection").append($s1);
			$("#examSection").append("<br>");

			var $ctrl2 = $('<input/>').attr({ type: 'radio', id:'ans2'});
			$("#examSection").append($ctrl2);
			$("#examSection").append("<br>");

			var $ctrl3 = $('<input/>').attr({ type: 'radio', id:'ans3'});
			$("#examSection").append($ctrl3);
			$("#examSection").append("<br>");

			var $ctrl4 = $('<input/>').attr({ type: 'radio', id:'ans4'});
			$("#examSection").append($ctrl4);
			$("#examSection").append("<br>");
		}
	});
}





