import { Injectable, OnInit } from '@angular/core';
import {Book} from './book';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class BookService implements OnInit {

  constructor(private http: HttpClient) { }
  public _url='../assets/booklist.json';
  ngOnInit(){
    this.getBookList();
  }

  getBookList(): Observable<Book[]>{
    return this.http.get<Book[]>(this._url);
  }
  
}
