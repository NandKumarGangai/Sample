$(document).ready(function(){
	$("#quizzSection").hide();
	$("#rulesSection").hide();
});

function checkCredentials(){
	
	var uname = document.getElementById("txtUserName").value;
	var pass = document.getElementById("txtPassword").value;
	var userData;
	//console.log(uname, pass);
	$.get("authentication.json", function(data, status){
		console.log(data);
		var t = data;
		var users = JSON.parse(t);
		console.log(users);
		let flag = false;
		for(user of users){
			
			if(user.username == uname && user.password==pass){
				
				$("#rulesSection").show();
				$("#loginSection").hide();
				$("#rulesSection").load("rules.html");
				flag = true;
				break;
				//console.log("check");
			}
		}
		if(flag == false){
			
			console.log("Invalid");
			document.getElementById("errLogin").innerHTML = "Invalid login credentials...";
		}
		
	});	
	return false;
}

function startQuizz(){
	alert("HELLO");
	console.log("HELLO");
	$("#examSection").load("exam.html");
	$.get("questions.json", function(data, status){
		
		console.log(data);
	});
}



