import { Component, OnInit } from '@angular/core';
import {IEmployee} from './employee';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

    empId:number;
    empName:string;
    empSalary:number;
    empDept:string;

  empList:IEmployee[] = [{"empId":1001,"empName":"Rahul","empSalary":9000,"empDept":"Java"},
  {"empId":1002,"empName":"Sachin","empSalary":19000,"empDept":"OraApps"},
  {"empId":1003,"empName":"Vikash","empSalary":29000,"empDept":"BI"}
];
  constructor() { }

  ngOnInit() {
  }

  deleteRow(id):void{
    for(let i = 0; i < this.empList.length; ++i){
        if (this.empList[i].empId === id) {
            this.empList.splice(i,1);
        }
    }
  }
  addEmployee():void{
    let emp = JSON.parse(`{"empId":${this.empId},"empName":"${this.empName}","empSalary":${this.empSalary},"empDept":"${this.empDept}"}`);
    this.empList.push(emp);
  }

}
